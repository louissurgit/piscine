<?php 

if(isset($_GET['action']) && $_GET['action']!=null ){
    $action = $_GET['action'];    

    switch ($action){
        case "compte":
            
            require("src/controller/connexionController.php");
            $connexionController = new ConnexionController();
           
            $connexionController->getConnection();
            break;
        case "recherche":
            require("src/templates/recherche.php");
            break;
        case "rdv":
            require('src/controller/rdvController.php');
            $rdvController=new RdvController();
            if(isset($_SESSION['currentUser'])){
                $currDate = date('Y-m-d');  
                $rdvs = $rdvController->getRdvsByMail($_SESSION['currentUser']['mail']);      
               
            }
            require("src/templates/rdv.php");
            break;
        case "inscription":
            require("src/templates/inscription.php");
            break;
        case "login":
            require("src/controller/connexionController.php");
            $connexionController = new ConnexionController();
            $connexionController->getConnection();
            break;
        case "activite":
            require("src/templates/parcourir.php");
            require('src/templates/activite.php');
            break;
        case "sport":
            require("src/templates/parcourir.php");
            require('src/templates/sport.php');
            break;
        case "salle":
            require("src/templates/parcourir.php");
            require('src/templates/salle.php');
            break;
        case "parcourir":
            require("src/templates/parcourir.php");
            require("src/templates/container.php");
            break;
        case "creationUser":
            require("src/controller/userController.php");

            $userController=new UserController();
            $userController->addUser();
            break;
        case "deconnexion":
            $_SESSION['connected']=false;
            require("src/controller/connexionController.php");
            $connexionController = new ConnexionController();
            $connexionController->getConnection();
            break;
        case "creationCoach":
            require("src/controller/coachController.php");

            $coachController=new CoachController();
            $coachController->addCoach();
            break;
        case "addRdv":
            require('src/controller/rdvController.php');
            $rdvController=new RdvController();
            if(isset($_GET['coachMail'])){
                $rdvController->createRdv();
            }
            break;
        case "annulerRdv":
            require('src/controller/rdvController.php');
            $rdvController=new RdvController();
            if(isset($_GET['rdvId'])){
                $id=$_GET['rdvId'];
                $rdvController->annulerRdv($id);
            }
            break;
        case "find":
            require('src/controller/findController.php');
            $findController=new FindController();
            if(isset($_GET['search'])){
                $search=$_GET['search'];
                $findController->find($search);
            }
            break;
        default :
            require("src/templates/home.php");
            break;
    }
}else{
    require("src/templates/home.php");
}





?>
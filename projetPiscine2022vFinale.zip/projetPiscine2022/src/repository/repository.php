<?php
    require('src/database.php');

    class UserRepository extends Database{

        public function getUserByMail($mail,$password){
            $connection = (new Database())->getConnection();
            $result = self::createQuery("SELECT * FROM user WHERE mail="."'".$mail."'"." AND password="."'".$password."'",$connection);
            return mysqli_fetch_array($result);
        }

        public function createUser($prenom,$nom,$mail,$password,$phone,$adresse,$cp,$ville,$idCarte,$pays){
            $connection = (new Database())->getConnection();
            return self::createQuery("INSERT INTO `user` (`role`, `mail`, `nom`, `prenom`, `adresse1`, `ville`, `cp`, `pays`, `phone`, `idCarteEtudiant`, `password`) 
            VALUES ('user', "."'".$mail."'".", "."'".$nom."'".", "."'".$prenom."'".", "."'".$adresse."'".", "."'".$ville."'".", "."'".$cp."'".", "."'".$pays."'".", "."'".
            $phone."'".", "."'".$idCarte."'".", "."'".$password."'".")
            ",$connection);
        }
    }

    class CoachRepository extends Database{
        public function getOneCoachBySpecialite($specialite){   
            $connection = (new Database())->getConnection();
            $result = self::createQuery("SELECT prenom, nom,mail, skype, photo, specialites, phone FROM `coach` WHERE specialites="."'".$specialite."' LIMIT 1",$connection);
            if($result){
                $resultArray= mysqli_fetch_array($result);
                if(!empty($resultArray)){
                
                    $base64 = base64_encode($resultArray['photo']);
                    $resultArray['photo']=$base64;
                    return $resultArray;
                }else{
                    return;
                }
            }
        }


        public function getCoachBySpecialite($specialite){   
            $connection = (new Database())->getConnection();
            $result = self::createQuery("SELECT prenom, nom,mail, skype, photo, specialites, phone FROM `coach` WHERE specialites="."'".$specialite."'",$connection);
            if($result){
                $resultArray= mysqli_fetch_array($result);
                if(!empty($resultArray)){
                
                    $base64 = base64_encode($resultArray['photo']);
                    $resultArray['photo']=$base64;
                    return $resultArray;
                }else{
                    return;
                }
            }
        }

        public function getCoachByPrenom($prenom){    
            $connection = (new Database())->getConnection();
            $result = self::createQuery("SELECT `prenom`,`nom`,`specialite`,`photo`,`skype` FROM `coach` WHERE prenom="."'".$prenom."'",$connection);
            
            if($result){
                $resultArray= mysqli_fetch_array($result);
                if(!empty($resultArray)){
                
                    $base64 = base64_encode($resultArray['photo']);
                    $resultArray['photo']=$base64;
                    return $resultArray;
                }else{
                    return;
                }
            }
        }

        public function getCoachByNom($nom){    
            $connection = (new Database())->getConnection();
            $result = self::createQuery("SELECT `prenom`,`nom`,`specialite`,`photo`,`skype` FROM `coach` WHERE nom="."'".$nom."'",$connection);
            if($result){
                $resultArray= mysqli_fetch_array($result);
                if(!empty($resultArray)){
                
                    $base64 = base64_encode($resultArray['photo']);
                    $resultArray['photo']=$base64;
                    return $resultArray;
                }else{
                    return;
                }
            }
        }


        public function getCoachByMail($mail,$password){    
            $connection = (new Database())->getConnection();
            $result = self::createQuery("SELECT * FROM `coach` WHERE mail="."'".$mail."'"." AND password="."'".$password."'",$connection);
            if($result){
                $resultArray= mysqli_fetch_array($result);
                if(!empty($resultArray)){
                
                    $base64 = base64_encode($resultArray['photo']);
                    $resultArray['photo']=$base64;
                    return $resultArray;
                }else{
                    return;
                }
            }
        }

       
        public function createCoach($prenom,$nom,$mail,$password,$phone,$adresse,$cp,$ville,$idCarte,$pays,$skype,$specialites,$role,$photo){
            $connection = (new Database())->getConnection();
            return self::createQuery("INSERT INTO `coach` (`role`, `mail`, `nom`, `prenom`, `adresse`, `ville`, `cp`, `pays`, `phone`, `skype`, `specialites`, `password`, `photo`) 
            VALUES ("."'".$role."'".", "."'".$mail."'".", "."'".$nom."'".", "."'".$prenom."'".", "."'".$adresse."'".", "."'".$ville."'".", "."'".$cp."'".", "."'".$pays."'".", "."'".
            $phone."'".", "."'".$skype."'".", "."'".$specialites."'".", "."'".$password."'".", "."'".$photo."'".")
            ",$connection);
        }
    }

    class RdvRepository extends Database{
        public function createRdv($userMail,$coachMail,$intitule,$miJournee,$date){
            $connection = (new Database())->getConnection();            
            $result = self::createQuery("INSERT INTO `rdv` (`date`, `userMail`, `coachMail`, `intitule`, `miJournee`) VALUES ( "."'".$date."'".", "."'".$userMail."'".", "."'".$coachMail."'".", "."'".$intitule."'".", "."'".$miJournee."'".")",$connection);
            return $result;
        }
        public function getRdvsByMail($mail){
            $connection = (new Database())->getConnection();            $result = self::createQuery("SELECT * FROM rdv WHERE userMail="."'".$mail."'",$connection);
            $resultArray=null;
            if($result){
                while ($row=mysqli_fetch_array($result)) {
                    $resultArray[]=$row;
                }
                return $resultArray;
            }else{
                $result = self::createQuery("SELECT * FROM rdv WHERE coachMail="."'".$mail."'",$connection);
                if($result){
                    while ($row=mysqli_fetch_array($result)) {
                        $resultArray[]=$row;
                    }
                    return $resultArray;
                }
            }
            return;  
        }

        

        public function annulerRdv($id){
            $connection = (new Database())->getConnection();            
            $result = self::createQuery("DELETE FROM `rdv` WHERE `rdv`.`id` = ".$id,$connection);
            return $result;  
            
        }
    }
?>
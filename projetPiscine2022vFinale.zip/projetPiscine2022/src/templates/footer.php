<footer>
    <div class="footer">
        <p class="footerText"> contact: 0601020304</p>
        <a href="https://www.google.fr/maps"><img style="width:30px;height:30px;border-radius:10px;margin:15px" src="https://upload.wikimedia.org/wikipedia/commons/a/aa/Google_Maps_icon_%282020%29.svg" alt="Google map"></img></a> 
        <a href="https://www.twitter.com"><img style="width:30px;height:30px;border-radius:10px;margin:15px" src="https://upload.wikimedia.org/wikipedia/fr/c/c8/Twitter_Bird.svg" alt="Twitter"></img></a> 
        <a href="https://www.facebook.com"><img style="width:30px;height:30px;border-radius:10px;margin:15px" src="https://upload.wikimedia.org/wikipedia/commons/d/d5/Facebook_F_icon.svg" alt="Facebook"></img></a> 
        <a href="https://www.instagram.com"><img style="width:30px;height:30px;border-radius:10px;margin:15px" src="https://upload.wikimedia.org/wikipedia/commons/e/e7/Instagram_logo_2016.svg" alt="Instagram"></img></a> 
        <p class="footerText"> Copyright Omnes Sport 2022</p>
   
    </div>
</footer>


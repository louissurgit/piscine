<div class="foundContainer">
    <div class="recherchePresentation" >
        <br>
       Nos résultats:
       <br>
       
    </div>
    <?php 
    if(isset($resultSpecialite)&&!empty($resultSpecialite)){
        $html="
            <div class='categorieCoach'>
            <div class='categorieImage'>
                <img class='coachImage' src='data:image/jpg;charset=utf8;base64,".$resultSpecialite['photo']."' alt='coachPhoto'/> 
            </div>
            <div class='coachTexte'>
                ".$resultSpecialite['prenom']." ".$resultSpecialite['nom']." 
                <br>
                Coach, ".$resultSpecialite['specialites']."
                <br>
                Telephone: ".$resultSpecialite['phone']." 
                <br>
                Mail: ".$resultSpecialite['mail']." 
            </div>
            <div class='disponibilites'>
            </div>
            <div class='coachButtons'>
            <ul>
                <form name='rdvForm' id='rdvCours' action='index.php?action=addRdv&coachMail=".$resultSpecialite['mail']."' method='POST' style='display:flex'>
                    <input type='hidden' name='intitule' id='intitule' placeholder='Intitule ' value='cours'/>
                    <input type='date' name='date' id='date' style='width:150px' required/>
                    <input type='text' name='miJournee' id='miJournee' placeholder='am ou pm'  style='width:100px' required/>
                    <div class='buttonContainer'><li><input type='submit' class='btn' value='Prendre Rdv'/></li></div>
                </form>
                <div class='buttonContainer'><a href='index.php?action=communiquer&coachMail=".$resultSpecialite['mail']."' class='navButton'><li><button class='btn'>Communiquer avec le coach</button></li></a></div>
                <div class='buttonContainer'><a href='index.php?action=cv&coachMail=".$resultSpecialite['mail']."' class='navButton'><li><button class='btn'>Voir son cv</button></li></a></div>
            </ul>
            </div> 
            </div>
    
        ";

        echo($html);
    }elseif(isset($resultPrenom)&&!empty($resultPrenom)){
        $html="
            <div class='categorieCoach'>
            <div class='categorieImage'>
                <img class='coachImage' src='data:image/jpg;charset=utf8;base64,".$resultPrenom['photo']."' alt='coachPhoto'/> 
            </div>
            <div class='coachTexte'>
                ".$resultPrenom['prenom']." ".$resultPrenom['nom']." 
                <br>
                Coach, ".$resultPrenom['specialites']."
                <br>
                Telephone: ".$resultPrenom['phone']." 
                <br>
                Mail: ".$resultPrenom['mail']." 
            </div>
            <div class='disponibilites'>
            </div>
            <div class='coachButtons'>
            <ul>
                <form name='rdvForm' id='rdvCours' action='index.php?action=addRdv&coachMail=".$resultPrenom['mail']."' method='POST' style='display:flex'>
                    <input type='hidden' name='intitule' id='intitule' placeholder='Intitule ' value='cours'/>
                    <input type='date' name='date' id='date' style='width:150px' required/>
                    <input type='text' name='miJournee' id='miJournee' placeholder='am ou pm'  style='width:100px' required/>
                    <div class='buttonContainer'><li><input type='submit' class='btn' value='Prendre Rdv'/></li></div>
                </form>
                <div class='buttonContainer'><a href='index.php?action=communiquer&coachMail=".$resultPrenom['mail']."' class='navButton'><li><button class='btn'>Communiquer avec le coach</button></li></a></div>
                <div class='buttonContainer'><a href='index.php?action=cv&coachMail=".$resultPrenom['mail']."' class='navButton'><li><button class='btn'>Voir son cv</button></li></a></div>
            </ul>
            </div> 
            </div>
    
        ";

        echo($html);
    }elseif(isset($resultNom)&&!empty($resultNom)){
        $html="
            <div class='categorieCoach'>
            <div class='categorieImage'>
                <img class='coachImage' src='data:image/jpg;charset=utf8;base64,".$resultNom['photo']."' alt='coachPhoto'/> 
            </div>
            <div class='coachTexte'>
                ".$resultNom['prenom']." ".$resultNom['nom']." 
                <br>
                Coach, ".$resultNom['specialites']."
                <br>
                Telephone: ".$resultNom['phone']." 
                <br>
                Mail: ".$resultNom['mail']." 
            </div>
            <div class='disponibilites'>
            </div>
            <div class='coachButtons'>
            <ul>
                <form name='rdvForm' id='rdvCours' action='index.php?action=addRdv&coachMail=".$resultNom['mail']."' method='POST' style='display:flex'>
                    <input type='hidden' name='intitule' id='intitule' placeholder='Intitule ' value='cours'/>
                    <input type='date' name='date' id='date' style='width:150px' required/>
                    <input type='text' name='miJournee' id='miJournee' placeholder='am ou pm'  style='width:100px' required/>
                    <div class='buttonContainer'><li><input type='submit' class='btn' value='Prendre Rdv'/></li></div>
                </form>
                <div class='buttonContainer'><a href='index.php?action=communiquer&coachMail=".$resultNom['mail']."' class='navButton'><li><button class='btn'>Communiquer avec le coach</button></li></a></div>
                <div class='buttonContainer'><a href='index.php?action=cv&coachMail=".$resultNom['mail']."' class='navButton'><li><button class='btn'>Voir son cv</button></li></a></div>
            </ul>
            </div> 
            </div>
    
        ";

        echo($html);
    }
    
    
    
    ?>
</div>
<?php
    require('src/controller/coachController.php');
    $coachController = new CoachController();
    $musculation=$coachController->getOneCoachBySpecialite('musculation');
    $fitness=$coachController->getOneCoachBySpecialite('fitness');
    $biking=$coachController->getOneCoachBySpecialite('biking');
    $cardio=$coachController->getOneCoachBySpecialite('cardio');
    $cours=$coachController->getOneCoachBySpecialite('cours');
?>

<!-- JAVASCRIPT -->
<script>
$(document).ready(function() {
  $(function() {
   
    $( "#dialog" ).dialog({
        autoOpen: false,
        title: 'Coordonnées'
    });
  });
  function openDialog(skype,phone,mail){
    console.log("click");
       
       $( "#dialog" ).dialog('open');
  }
  
}); 
</script>

<div id="dialog">
    
</div>


<div class="activiteContainer">
    <div id="musculation" class="categorie">
        <div class="categorieTitre">
            Musculation
        </div>
        <div class="categorieTexte">
            La musculation est un ensemble d'exercices physiques visant le développement des muscles squelettiques, afin d'acquérir plus de force, d'endurance, de puissance, d'explosivité ou de volume musculaire. 
            <br>
            Dans ces exercices, une force (par exemple la gravité, avec l'utilisation d'haltères, de bandes élastiques ou encore à l'aide du poids du corps) est opposée de manière répétitive à la force générée par la contraction des muscles. Cette activité est généralement pratiquée dans une salle de sport.
        </div>
        <br>
        <div class="categorieCoach">
            <div class="categorieImage">
                <img class="coachImage" src="data:image/jpg;charset=utf8;base64,<?php echo $musculation['photo']; ?>" alt="coachPhoto"/> 
            </div>
            <div class="coachTexte">
                <?php echo $musculation['prenom']." ".$musculation['nom']; ?> 
                <br>
                Coach, Musculation
                <br>
                Telephone: <?php echo $musculation['phone']; ?> 
                <br>
                Mail: <?php echo $musculation['mail']; ?> 
            </div>
             
            <div class="coachButtons">
            <ul>
                <form name="rdvForm" id="rdvMuscu" action="index.php?action=addRdv&coachMail=<?php echo $musculation['mail']; ?>" method="POST" style="display:flex">
                    <input type="hidden" name="intitule" id="intitule" placeholder="Intitule " value="musculation"/>
                    <input type="date" name="date" id="date" style="width:150px" required/>
                    <input type="text" name="miJournee" id="miJournee" placeholder="am ou pm"  style="width:100px" required/>
                    <div class="buttonContainer"><li><input type="submit" class="btn" value="Prendre Rdv"/></li></div>
                </form>          
                    <div class="buttonContainer"><li><button class="btn btnDialog" onClick="
                        $( '#dialog' ).empty();
                        $( '#dialog' ).append('numero: <?php echo $musculation['phone']; ?><br> Identifiant Skype: <?php echo $musculation['skype']; ?><br> Mail: <?php echo $musculation['mail']; ?>
                        ');
                        $( '#dialog' ).dialog('open');
                    ">Communiquer avec le coach</button></li></div>
                <div class="buttonContainer"><a href="https://www.linkedin.com/in/francois-bluy-6b1920175/" class="navButton"><li><button class="btn">Voir son cv</button></li></a></div>
            </ul>
            </div> 
        </div>
    </div>
    <br>
    <div id="fitness" class="categorie">
    <div class="categorieTitre">
            Fitness
        </div>
        <div class="categorieTexte">
        Le fitness (abréviation de l'expression anglaise physical fitness, « forme physique »), aussi appelé la gymnastique de forme1 ou l'entraînement physique2,
        <br> 
        désigne un ensemble d'activités physiques permettant au pratiquant d'améliorer sa condition physique et son hygiène de vie, dans un souci de bien-être.
        </div>
        <br>
        <div class="categorieCoach">
            <div class="categorieImage">
                <img class="coachImage" src="data:image/jpg;charset=utf8;base64,<?php echo $fitness['photo']; ?>" alt="coachPhoto"/> 
            </div>
            <div class="coachTexte">
                <?php echo $fitness['prenom']." ".$fitness['nom']; ?> 
                <br>
                Coach, Fitness
                <br>
                Telephone: <?php echo $fitness['phone']; ?> 
                <br>
                Mail: <?php echo $fitness['mail']; ?> 
            </div>
             
            <div class="coachButtons">
            <ul>
                <form name="rdvForm" id="rdvFitness" action="index.php?action=addRdv&coachMail=<?php echo $fitness['mail']; ?>" method="POST" style="display:flex">
                    <input type="hidden" name="intitule" id="intitule" placeholder="Intitule " value="fitness"/>
                    <input type="date" name="date" id="date" style="width:150px" required/>
                    <input type="text" name="miJournee" id="miJournee" placeholder="am ou pm"  style="width:100px" required/>
                    <div class="buttonContainer"><li><input type="submit" class="btn" value="Prendre Rdv"/></li></div>
                </form>
                <div class="buttonContainer"><li><button class="btn btnDialog" onClick="
                        $( '#dialog' ).empty();
                        $( '#dialog' ).append('numero: <?php echo $fitness['phone']; ?><br> Identifiant Skype: <?php echo $fitness['skype']; ?><br> Mail: <?php echo $fitness['mail']; ?>
                        ');
                        $( '#dialog' ).dialog('open');
                    ">Communiquer avec le coach</button></li></div>
                <div class="buttonContainer"><a href="https://www.linkedin.com/in/francois-bluy-6b1920175/" class="navButton"><li><button class="btn">Voir son cv</button></li></a></div>
            </ul>
            </div> 
        </div>
    </div>
    <br>
    <div id="biking" class="categorie">
    <div class="categorieTitre">
            Biking
        </div>
        <div class="categorieTexte">
        Le biking ou RPM est un cours de cyclisme indoor, qui consiste en l’utilisation de vélos fixes en salle, et en groupe, le tout en musique.
        <br>
        Encadrés par un coach sportif, les exercices proposés sont basés sur la résistance cardio respiratoire et le travail musculaire (essentiellement le bas du corps). Les intensités sont variées, afin de simuler un parcours de vélo précis. 
        </div>
        <br>
        <div class="categorieCoach">
            <div class="categorieImage">
                <img class="coachImage" src="data:image/jpg;charset=utf8;base64,<?php echo $biking['photo']; ?>" alt="coachPhoto"/> 
            </div>
            <div class="coachTexte">
                <?php echo $biking['prenom']." ".$biking['nom']; ?> 
                <br>
                Coach, Biking
                <br>
                Telephone: <?php echo $biking['phone']; ?> 
                <br>
                Mail: <?php echo $biking['mail']; ?> 
            </div>
             
            <div class="coachButtons">
            <ul>
                <form name="rdvForm" id="rdvBiking" action="index.php?action=addRdv&coachMail=<?php echo $biking['mail']; ?>" method="POST" style="display:flex">
                    <input type="hidden" name="intitule" id="intitule" placeholder="Intitule " value="biking"/>
                    <input type="date" name="date" id="date" style="width:150px" required/>
                    <input type="text" name="miJournee" id="miJournee" placeholder="am ou pm"  style="width:100px" required/>
                    <div class="buttonContainer"><li><input type="submit" class="btn" value="Prendre Rdv"/></li></div>
                </form>                
                <div class="buttonContainer"><li><button class="btn btnDialog" onClick="
                        $( '#dialog' ).empty();
                        $( '#dialog' ).append('numero: <?php echo $biking['phone']; ?><br> Identifiant Skype: <?php echo $biking['skype']; ?><br> Mail: <?php echo $biking['mail']; ?>
                        ');
                        $( '#dialog' ).dialog('open');
                    ">Communiquer avec le coach</button></li></div>
                <div class="buttonContainer"><a href="https://www.linkedin.com/in/francois-bluy-6b1920175/" class="navButton"><li><button class="btn">Voir son cv</button></li></a></div>
            </ul>
            </div> 
        </div>
    </div>
    <br>
    <div id="cardioTraining" class="categorie"> 
    <div class="categorieTitre">
            Cardio-training
        </div>
        <div class="categorieTexte">
        Le cardio-training (littéralement "l'entraînement du cœur") rassemble des activités de fitness sollicitant le muscle cardiaque afin de l'entraîner à l'effort et ainsi de renforcer les systèmes cardio-vasculaire et cardio-respiratoire. 
        <br>
        Courir, faire du vélo, de la natation, de l'aviron ou du rameur, du step ou encore de la zumba sont des activités de cardio-training.
        </div>
        <div class="categorieCoach">
            <div class="categorieImage">
                <img class="coachImage" src="data:image/jpg;charset=utf8;base64,<?php echo $cardio['photo']; ?>" alt="coachPhoto"/> 
            </div>
            <div class="coachTexte">
                <?php echo $cardio['prenom']." ".$cardio['nom']; ?> 
                <br>
                Coach, Cardio-Training
                <br>
                Telephone: <?php echo $cardio['phone']; ?> 
                <br>
                Mail: <?php echo $cardio['mail']; ?> 
            </div>
             
            <div class="coachButtons">
            <ul>
                <form name="rdvForm" id="rdvCardio" action="index.php?action=addRdv&coachMail=<?php echo $cardio['mail']; ?>" method="POST" style="display:flex">
                <input type="hidden" name="intitule" id="intitule" placeholder="Intitule " value="cardio"/>
                    <input type="date" name="date" id="date" style="width:150px" required/>
                    <input type="text" name="miJournee" id="miJournee" placeholder="am ou pm"  style="width:75px" required/>
                    <div class="buttonContainer"><li><input type="submit" class="btn" value="Prendre Rdv"/></li></div>
                </form>
                <div class="buttonContainer"><li><button class="btn btnDialog" onClick="
                        $( '#dialog' ).empty();
                        $( '#dialog' ).append('numero: <?php echo $cardio['phone']; ?><br> Identifiant Skype: <?php echo $cardio['skype']; ?><br> Mail: <?php echo $cardio['mail']; ?>
                        ');
                        $( '#dialog' ).dialog('open');
                    ">Communiquer avec le coach</button></li></div>
                <div class="buttonContainer"><a href="https://www.linkedin.com/in/francois-bluy-6b1920175/" class="navButton"><li><button class="btn">Voir son cv</button></li></a></div>
            </ul>
            </div> 
        </div>
    </div>
    <br>
    <div id="coursCollectif" class="categorie"> 
    <div class="categorieTitre">
            Cours collectif
        </div>
        <div class="categorieTexte">
        Les cours collectifs d'Omnes regroupent plusieurs formats d’activités et différentes méthodes d’exercices. Chacun d’entre eux permet d’atteindre des objectifs différents.
        <br>
        Dépense calorique, perte de poids, musculation, force, endurance, tonicité du corps… Tu trouveras toujours un cours qui permet de répondre à ton besoin.
        </div>
        <br>
        <div class="categorieCoach">
            <div class="categorieImage">
                <img class="coachImage" src="data:image/jpg;charset=utf8;base64,<?php echo $cours['photo']; ?>" alt="coachPhoto"/> 
            </div>
            <div class="coachTexte">
                <?php echo $cours['prenom']." ".$cours['nom']; ?> 
                <br>
                Coach, Cours Collectif
                <br>
                Telephone: <?php echo $cours['phone']; ?> 
                <br>
                Mail: <?php echo $cours['mail']; ?> 
            </div>
             
            <div class="coachButtons">
            <ul>
                <form name="rdvForm" id="rdvCours" action="index.php?action=addRdv&coachMail=<?php echo $cours['mail']; ?>" method="POST" style="display:flex">
                    <input type="hidden" name="intitule" id="intitule" placeholder="Intitule " value="cours"/>
                    <input type="date" name="date" id="date" style="width:150px" required/>
                    <input type="text" name="miJournee" id="miJournee" placeholder="am ou pm"  style="width:100px" required/>
                    <div class="buttonContainer"><li><input type="submit" class="btn" value="Prendre Rdv"/></li></div>
                </form>
                <div class="buttonContainer"><li><button class="btn btnDialog" onClick="
                        $( '#dialog' ).empty();
                        $( '#dialog' ).append('numero: <?php echo $cours['phone']; ?><br> Identifiant Skype: <?php echo $cours['skype']; ?><br> Mail: <?php echo $cours['mail']; ?>
                        ');
                        $( '#dialog' ).dialog('open');
                    ">Communiquer avec le coach</button></li></div>
                <div class="buttonContainer"><a href="https://www.linkedin.com/in/francois-bluy-6b1920175/" class="navButton"><li><button class="btn">Voir son cv</button></li></a></div>
            </ul>
            </div> 
        </div>
    </div>
</div>

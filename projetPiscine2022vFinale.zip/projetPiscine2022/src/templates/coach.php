
<div class="compteContainer">
       <div class="infosTitle">
           Vos informations
           <img id="coachPhotoPosition" class="coachPhoto" src="data:image/jpg;charset=utf8;base64,<?php echo $_SESSION['currentUser']['photo']; ?>" alt="coachPhoto"/> 
       </div>
       <table class="tableInfos">
            <tr>
                <td colspan=2 style="text-align:center !important;font-weight:bold">
                    <?php echo($_SESSION['currentUser']['prenom']." ".$_SESSION['currentUser']['nom'])?>
                </td>
            </tr>
            <tr>
            </tr>
            <tr>
                <td>
                    Mail:
                </td>
                <td>
                    <?php echo($_SESSION['currentUser']['mail'])?>
                </td>
            </tr>
            <tr>
                <td>
                    Telephone:
                </td>
                <td>
                    <?php echo($_SESSION['currentUser']['phone'])?>
                </td>
            </tr>
            <tr>
                <td>
                    Adresse:
                </td>
                <td>
                    <?php echo($_SESSION['currentUser']['adresse'])?>
                </td>
            </tr>
            <tr>
                <td>
                    Spécialité:
                </td>
                <td>
                    <?php echo($_SESSION['currentUser']['specialites'])?>
                </td>
            </tr>
            
        </table>
        <br>
        <a href="index.php?action=deconnexion" style="text-decoration:none;">Se déconnecter</a>
</div>

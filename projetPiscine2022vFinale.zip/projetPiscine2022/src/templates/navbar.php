<header>
    <div class="logoContainer">
            <a href="index.php" class="logo">Omnes Sport</a>
    </div>
        <div class="nav">
            <ul>
                <div class="buttonContainer"><a href="index.php" class="navButton"><li><button class="btn">Accueil</button></li></a></div>
                <div class="buttonContainer"><a href="index.php?action=parcourir" class="navButton"><li><button class="btn">Tout Parcourir</button></li></a></div>
                <div class="buttonContainer"><a href="index.php?action=recherche" class="navButton"><li><button class="btn">Recherche</button></li></a></div>
                <div class="buttonContainer"><a href="index.php?action=rdv" class="navButton"><li><button class="btn">Rendez-vous</button></li></a></div>
                <div class="buttonContainer"><a href="index.php?action=compte" class="navButton"><button class="btn">
                    Votre Compte
                </button></li></a></div>
            </ul>
        </div>
</header>

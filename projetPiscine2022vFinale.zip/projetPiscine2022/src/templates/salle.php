<div class="salleContainer">
    <div class="infosSalle">
        (NEWS) Le passe sanitaire n'est plus requis pour venir en salle!
      
    </div>
    <div id="regles" class="categorie">

        <p style="font-weight:bold;"> Regles des salles de sports :  </p> 
        1- Ne pas ramener de la nourriture 
        <br>
        2- La serviette est obligatoire, question d'hygiène!
        <br>
        3- Le partage de la carte d'accès est interdit
        <br>
        4- Sourire est obligatoire dans nos enseignes

    </div>
    <div id="horaires" class="categorie">
        <p style="font-weight:bold;">Horaires</p> 
        lundi: 7h à 22h
        <br>
        mardi: 7h à 22h
        <br>
        mercredi: 7h à 22h
        <br>
        jeudi: 7h à 22h
        <br>
        vendredi: 7h à 22h
        <br>
        samedi: 9h à 22h
        <br>
        lundi: 9h à 18h
        <br>
    </div>
    <br>
    <div id="coordonnees" class="categorie"> 
        <p style="font-weight:bold;">Cordonnées de contact du responsable:</p>
        
        <br>
        mail: contact@omnes.com
        <br>
        telephone: 0782828218
        
    </div>
</div>

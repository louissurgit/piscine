<div class="loginContainer">
    <div class="marginContainer">

    
        <form id="loginForm" action="index.php?action=login" method="post" class="tableFormLogin" style="margin-left:36%;margin-top:50px !important" >
            <table>
            <tr>
                <td>
                    <label> 
                        Mail
                    </label>
                </td>
                <td>
                    <input type="text" id="mail" name="mail" placeholder="jeandubois@mail.com" style="height:25px;width:170px;" required />
                </td>
            </tr>
            <tr>
                <td>
                    <label> 
                        Mot de passe
                    </label>
                </td>
                <td>
                    <input type="password" id="password" name="password" style="height:25px;width:170px;" required />
                </td>
            </tr>
            <tr>
                <td colspan=2>
                <input type="submit" id="submit" name="submit" class="submitLogin" value="Se connecter"/>
                </td> 
            </tr>
            </table>
        </form>
    
    <p> Pas encore inscrit? </p> <a href="index.php?action=inscription" style="text-decoration:none">Créez votre compte </a>
    </div>

</div>
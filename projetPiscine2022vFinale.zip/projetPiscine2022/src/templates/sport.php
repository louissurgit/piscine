<?php
    require('src/controller/coachController.php');
    $coachController = new CoachController();
    $basketball=$coachController->getOneCoachBySpecialite('basketball');
    $football=$coachController->getOneCoachBySpecialite('football');
    $rugby=$coachController->getOneCoachBySpecialite('rugby');
    $tennis=$coachController->getOneCoachBySpecialite('tennis');
    $natation=$coachController->getOneCoachBySpecialite('natation');
    $plongeon=$coachController->getOneCoachBySpecialite('plongeon');
?>


<!-- JAVASCRIPT -->
<script>
$(document).ready(function() {
  $(function() {
   
    $( "#dialog" ).dialog({
        autoOpen: false,
        title: 'Coordonnées'
    });
  });
  function openDialog(skype,phone,mail){
    console.log("click");
       
       $( "#dialog" ).dialog('open');
  }
  
}); 
</script>

<div id="dialog">
    
</div>

<div class="activiteContainer">
    <div id="basketball" class="categorie">
        <div class="categorieTitre">
            Basketball
        </div>
        <div class="categorieTexte">
        Le basket-ball ou basketball, fréquemment désigné en français par son abréviation basket, est un sport collectif de balle opposant deux équipes de cinq joueurs sur un terrain rectangulaire.
        </div>
        <br>
        <div class="categorieCoach">
            <div class="categorieImage">
                <img class="coachImage" src="data:image/jpg;charset=utf8;base64,<?php echo $basketball['photo']; ?>" alt="coachPhoto"/> 
            </div>
            <div class="coachTexte">
                <?php echo $basketball['prenom']." ".$basketball['nom']; ?> 
                <br>
                Coach, Basketball
                <br>
                Telephone: <?php echo $basketball['phone']; ?> 
                <br>
                Mail: <?php echo $basketball['mail']; ?> 
            </div>
             
            <div class="coachButtons">
            <ul>
                <form name="rdvForm" id="rdvBasketball" action="index.php?action=addRdv&coachMail=<?php echo $basketball['mail']; ?>" method="POST" style="display:flex">
                    <input type="hidden" name="intitule" id="intitule" placeholder="Intitule " value="basketball"/>
                    <input type="date" name="date" id="date" style="width:150px" required/>
                    <input type="text" name="miJournee" id="miJournee" placeholder="am ou pm"  style="width:100px" required/>
                    <div class="buttonContainer"><li><input type="submit" class="btn" value="Prendre Rdv"/></li></div>
                </form>
                <div class="buttonContainer"><li><button class="btn btnDialog" onClick="
                        $( '#dialog' ).empty();
                        $( '#dialog' ).append('numero: <?php echo $basketball['phone']; ?><br> Identifiant Skype: <?php echo $basketball['skype']; ?><br> Mail: <?php echo $basketball['mail']; ?>
                        ');
                        $( '#dialog' ).dialog('open');
                    ">Communiquer avec le coach</button></li></div>
                <div class="buttonContainer"><a href="https://www.linkedin.com/in/francois-bluy-6b1920175/" class="navButton"><li><button class="btn">Voir son cv</button></li></a></div>
            </ul>
            </div> 
        </div>
    </div>
    <br>
    <div id="football" class="categorie">
    <div class="categorieTitre">
            Football
        </div>
        <div class="categorieTexte">
        Le football est un sport collectif qui se joue avec un ballon sphérique entre deux équipes de onze joueurs. Elles s'opposent sur un terrain rectangulaire équipé d'un but à chaque extrémité. L'objectif de chaque camp est de mettre le ballon dans le but adverse plus de fois que l'autre équipe, sans que les joueurs utilisent leurs bras à l'exception des gardiens de buts.
        </div>
        <br>
        <div class="categorieCoach">
            <div class="categorieImage">
                <img class="coachImage" src="data:image/jpg;charset=utf8;base64,<?php echo $football['photo']; ?>" alt="coachPhoto"/> 
            </div>
            <div class="coachTexte">
                <?php echo $football['prenom']." ".$football['nom']; ?> 
                <br>
                Coach, Football
                <br>
                Telephone: <?php echo $football['phone']; ?> 
                <br>
                Mail: <?php echo $football['mail']; ?> 
            </div>
             
            <div class="coachButtons">
            <ul>
                <form name="rdvForm" id="rdvFootball" action="index.php?action=addRdv&coachMail=<?php echo $football['mail']; ?>" method="POST" style="display:flex">
                    <input type="hidden" name="intitule" id="intitule" placeholder="Intitule " value="football"/>
                    <input type="date" name="date" id="date" style="width:150px" required/>
                    <input type="text" name="miJournee" id="miJournee" placeholder="am ou pm"  style="width:100px" required/>
                    <div class="buttonContainer"><li><input type="submit" class="btn" value="Prendre Rdv"/></li></div>
                </form>
                <div class="buttonContainer"><li><button class="btn btnDialog" onClick="
                        $( '#dialog' ).empty();
                        $( '#dialog' ).append('numero: <?php echo $football['phone']; ?><br> Identifiant Skype: <?php echo $football['skype']; ?><br> Mail: <?php echo $football['mail']; ?>
                        ');
                        $( '#dialog' ).dialog('open');
                    ">Communiquer avec le coach</button></li></div>
                <div class="buttonContainer"><a href="https://www.linkedin.com/in/francois-bluy-6b1920175/" class="navButton"><li><button class="btn">Voir son cv</button></li></a></div>
            </ul>
            </div> 
        </div>
    </div>
    <br>
    <div id="rugby" class="categorie">
    <div class="categorieTitre">
            Rugby
        </div>
        <div class="categorieTexte">
        Le rugby à XV, aussi appelé rugby union dans les pays anglophones, qui se joue par équipes de quinze joueurs sur le terrain avec des remplaçants, est la variante la plus pratiquée du rugby, famille de sports collectifs, dont les spécificités sont les mêlées et les touches, mettant aux prises deux équipes qui se disputent un ballon ovale, joué à la main et au pied.
        </div>
        <br>
        <div class="categorieCoach">
            <div class="categorieImage">
                <img class="coachImage" src="data:image/jpg;charset=utf8;base64,<?php echo $rugby['photo']; ?>" alt="coachPhoto"/> 
            </div>
            <div class="coachTexte">
                <?php echo $rugby['prenom']." ".$rugby['nom']; ?> 
                <br>
                Coach, Rugby
                <br>
                Telephone: <?php echo $rugby['phone']; ?> 
                <br>
                Mail: <?php echo $rugby['mail']; ?> 
            </div>
             
            <div class="coachButtons">
            <ul>
                <form name="rdvForm" id="rdvRugby" action="index.php?action=addRdv&coachMail=<?php echo $rugby['mail']; ?>" method="POST" style="display:flex">
                    <input type="hidden" name="intitule" id="intitule" placeholder="Intitule " value="rugby"/>
                    <input type="date" name="date" id="date" style="width:150px" required/>
                    <input type="text" name="miJournee" id="miJournee" placeholder="am ou pm"  style="width:100px" required/>
                    <div class="buttonContainer"><li><input type="submit" class="btn" value="Prendre Rdv"/></li></div>
                </form>
                <div class="buttonContainer"><li><button class="btn btnDialog" onClick="
                        $( '#dialog' ).empty();
                        $( '#dialog' ).append('numero: <?php echo $rugby['phone']; ?><br> Identifiant Skype: <?php echo $rugby['skype']; ?><br> Mail: <?php echo $rugby['mail']; ?>
                        ');
                        $( '#dialog' ).dialog('open');
                    ">Communiquer avec le coach</button></li></div>
                <div class="buttonContainer"><a href="https://www.linkedin.com/in/francois-bluy-6b1920175/" class="navButton"><li><button class="btn">Voir son cv</button></li></a></div>
            </ul>
            </div> 
        </div>
    </div>
    <div id="tennis" class="categorie"> 
    <div class="categorieTitre">
            Tennis
        </div>
        <div class="categorieTexte">
        Le tennis est un sport de raquette qui oppose soit deux joueurs (on parle alors de jeu en simple) soit quatre joueurs qui forment deux équipes de deux (on parle alors de jeu en double). Les joueurs utilisent une raquette cordée verticalement et horizontalement (en tamis) à une tension variant avec la puissance ou l'effet que l'on veut obtenir.
        </div>
        <div class="categorieCoach">
            <div class="categorieImage">
                <img class="coachImage" src="data:image/jpg;charset=utf8;base64,<?php echo $tennis['photo']; ?>" alt="coachPhoto"/> 
            </div>
            <div class="coachTexte">
                <?php echo $tennis['prenom']." ".$tennis['nom']; ?> 
                <br>
                Coach, Tennis
                <br>
                Telephone: <?php echo $tennis['phone']; ?> 
                <br>
                Mail: <?php echo $tennis['mail']; ?> 
            </div>
             
            <div class="coachButtons">
            <ul>
                <form name="rdvForm" id="rdvTennis" action="index.php?action=addRdv&coachMail=<?php echo $tennis['mail']; ?>" method="POST" style="display:flex">
                    <input type="hidden" name="intitule" id="intitule" placeholder="Intitule " value="tennis"/>
                    <input type="date" name="date" id="date" style="width:150px" required/>
                    <input type="text" name="miJournee" id="miJournee" placeholder="am ou pm"  style="width:100px" required/>
                    <div class="buttonContainer"><li><input type="submit" class="btn" value="Prendre Rdv"/></li></div>
                </form>
                <div class="buttonContainer"><li><button class="btn btnDialog" onClick="
                        $( '#dialog' ).empty();
                        $( '#dialog' ).append('numero: <?php echo $tennis['phone']; ?><br> Identifiant Skype: <?php echo $tennis['skype']; ?><br> Mail: <?php echo $tennis['mail']; ?>
                        ');
                        $( '#dialog' ).dialog('open');
                    ">Communiquer avec le coach</button></li></div>
                <div class="buttonContainer"><a href="https://www.linkedin.com/in/francois-bluy-6b1920175/" class="navButton"><li><button class="btn">Voir son cv</button></li></a></div>
            </ul>
            </div> 
        </div>
    </div>
    <br>
    <div id="natation" class="categorie"> 
        <div class="categorieTitre">
            Natation
        </div>
        <div class="categorieTexte">
        La natation, c'est-à-dire l'action de nager (Écouter), désigne les méthodes qui permettent aux êtres humains de se mouvoir dans l'eau sans aucune autre force propulsive que leur propre énergie corporelle.
        Parmi les activités humaines, la natation regroupe le déplacement à la surface de l'eau et sous l'eau (plongée, mermaiding, natation synchronisée, water-polo), le plongeon et divers jeux pratiqués dans l'eau.
        Elle se pratique en piscine, en eau libre (lac, mer), ou en eau vive (rivière).
        La natation est un sport olympique depuis 1896 pour les hommes et depuis 1912 pour les femmes.
        </div>
        <br>
        <div class="categorieCoach">
            <div class="categorieImage">
                <img class="coachImage" src="data:image/jpg;charset=utf8;base64,<?php echo $natation['photo']; ?>" alt="coachPhoto"/> 
            </div>
            <div class="coachTexte">
                <?php echo $natation['prenom']." ".$natation['nom']; ?> 
                <br>
                Coach, Natation
                <br>
                Telephone: <?php echo $natation['phone']; ?> 
                <br>
                Mail: <?php echo $natation['mail']; ?> 
            </div>
             
            <div class="coachButtons">
            <ul>
                <form name="rdvForm" id="rdvNatation" action="index.php?action=addRdv&coachMail=<?php echo $natation['mail']; ?>" method="POST" style="display:flex">
                    <input type="hidden" name="intitule" id="intitule" placeholder="Intitule " value="natation"/>
                    <input type="date" name="date" id="date" style="width:150px" required/>
                    <input type="text" name="miJournee" id="miJournee" placeholder="am ou pm"  style="width:100px" required/>
                    <div class="buttonContainer"><li><input type="submit" class="btn" value="Prendre Rdv"/></li></div>
                </form>
                <div class="buttonContainer"><li><button class="btn btnDialog" onClick="
                        $( '#dialog' ).empty();
                        $( '#dialog' ).append('numero: <?php echo $natation['phone']; ?><br> Identifiant Skype: <?php echo $natation['skype']; ?><br> Mail: <?php echo $natation['mail']; ?>
                        ');
                        $( '#dialog' ).dialog('open');
                    ">Communiquer avec le coach</button></li></div>
                <div class="buttonContainer"><a href="https://www.linkedin.com/in/francois-bluy-6b1920175/" class="navButton"><li><button class="btn">Voir son cv</button></li></a></div>
            </ul>
            </div> 
        </div>
    </div>
    <br>
    <div id="plongeon" class="categorie"> 
        <div class="categorieTitre">
            Plongeon
        </div>
        <div class="categorieTexte">
        Le plongeon consiste à se lancer dans l'eau d'une hauteur plus ou moins importante1. Il peut être effectué pour s'amuser, pour prendre le départ d'une course de natation ou pratiqué comme un sport à part entière. Dans ce dernier cas, il s'agit, en s'élançant de différentes hauteurs, d'effectuer devant un jury des figures acrobatiques codifiées avant de pénétrer dans l'eau.
        </div>
        <br>
        <div class="categorieCoach">
            <div class="categorieImage">
                <img class="coachImage" src="data:image/jpg;charset=utf8;base64,<?php echo $plongeon['photo']; ?>" alt="coachPhoto"/> 
            </div>
            <div class="coachTexte">
                <?php echo $plongeon['prenom']." ".$plongeon['nom']; ?> 
                <br>
                Coach, Plongeon
                <br>
                Telephone: <?php echo $plongeon['phone']; ?> 
                <br>
                Mail: <?php echo $plongeon['mail']; ?> 
            </div>
             
            <div class="coachButtons">
            <ul>
                <form name="rdvForm" id="rdvPlongeon" action="index.php?action=addRdv&coachMail=<?php echo $plongeon['mail']; ?>" method="POST" style="display:flex">
                    <input type="hidden" name="intitule" id="intitule" placeholder="Intitule " value="plongeon"/>
                    <input type="date" name="date" id="date" style="width:150px" required/>
                    <input type="text" name="miJournee" id="miJournee" placeholder="am ou pm"  style="width:100px" required/>
                    <div class="buttonContainer"><li><input type="submit" class="btn" value="Prendre Rdv"/></li></div>
                </form>
                <div class="buttonContainer"><li><button class="btn btnDialog" onClick="
                        $( '#dialog' ).empty();
                        $( '#dialog' ).append('numero: <?php echo $plongeon['phone']; ?><br> Identifiant Skype: <?php echo $plongeon['skype']; ?><br> Mail: <?php echo $plongeon['mail']; ?>
                        ');
                        $( '#dialog' ).dialog('open');
                    ">Communiquer avec le coach</button></li></div>
                <div class="buttonContainer"><a href="https://www.linkedin.com/in/francois-bluy-6b1920175/" class="navButton"><li><button class="btn">Voir son cv</button></li></a></div>
            </ul>
            </div> 
        </div>
    </div>
    
</div>

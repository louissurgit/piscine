<div class="rechercheContainer">
    <div class="recherchePresentation" >
        A la recherche d'un élement en particulier ?
    </div>
    <form class="rechercheForm" name="rechercheForm" id="rechercheForm" action="index.php?" class="rechercheContainerBis" method="GET">
        <input type="text" name="search" id="search" placeholder="Enter keywords" class="searchInput"/>
        <input type="hidden" name="action" value="find" />
        <input type="submit" name="submit" class="submitLogin" id="imageButton" placeholder="Rechercher" />
    </form>
    <div class="rechercheText" >
        Veuillez entrer des mots clés comme: tennis, rugby, natation ou des nom/prenom de coach travaillant chez nous.
    </div>
</div>
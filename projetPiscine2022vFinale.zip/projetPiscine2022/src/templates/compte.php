


<div class="homeContainer">
       <div class="infosTitle">
           Vos informations
       </div>
       <table class="tableInfos">
            <tr>
                <td colspan=2 style="text-align:center !important;font-weight:bold">
                    <?php echo($_SESSION['currentUser']['prenom']." ".$_SESSION['currentUser']['nom'])?>
                </td>
            </tr>
            <tr>
            </tr>
            <tr>
                <td>
                    Mail:
                </td>
                <td>
                    <?php echo($_SESSION['currentUser']['mail'])?>
                </td>
            </tr>
            <tr>
                <td>
                    Telephone:
                </td>
                <td>
                    <?php echo($_SESSION['currentUser']['phone'])?>
                </td>
            </tr>
            <tr>
                <td>
                    Adresse:
                </td>
                <td>
                    <?php echo($_SESSION['currentUser']['adresse1'])?>
                </td>
            </tr>
            <tr>
                <td>
                    Role:
                </td>
                <td>
                    <?php echo($_SESSION['currentUser']['role'])?>
                </td>
            </tr>
            
            
        </table>
        <br>
        <a href="index.php?action=deconnexion" style="text-decoration:none;">Se déconnecter</a>
</div>
<div class="homeContainer">
    <div class="presentation">
        <h2 class="titre"> Vos anciens RDV </h2>
        <?php
        
        if(isset($anciensRdv)&&!empty($anciensRdv)){
            for($i = 0; $i < sizeof($anciensRdv); $i++){
              
                $html = 
                "<div class='rdvAVenir'>
                    Date: ".$anciensRdv[$i]['date']." ".$anciensRdv[$i]['miJournee']."
                    <br>
                    <br>
                    Mail du Coach: ".$anciensRdv[$i]['coachMail']."
                    <br>
                    <br>
                    Pour: ".$anciensRdv[$i]['intitule']."
                </div>";
                echo($html);
            }
        }
        ?>
    </div>
</div>


<?php

   
?>


<div class="rdvContainer">
    <div class="rdvTitre">
        Vos rendez-vous à venir
        
       
    </div>
    <p style="font-style: italic">
            PS: Les anciens rendez-vous sont affichés sur votre compte 
        </p> 
    <?php
    if(isset($_SESSION['currentUser'])){
        if(isset($rdvs[1])){
            foreach ($rdvs as $rdv){
                if($rdv['date']>$currDate){
                    $html = 
                    "<div class='rdvAVenir'>
                        Date: ".$rdv['date']." ".$rdv['miJournee']."
                        <br>
                        <br>
                        Mail du Coach: ".$rdv['coachMail']."
                        <br>
                        <br>
                        Pour: ".$rdv['intitule']."
                        <br>
                        <br>
                        <a style='text-decoration:none' href='index.php?action=annulerRdv&rdvId=".$rdv['id']."'>Annuler le rendez-vous</a> 
                    </div>";
                    echo($html);
                }
            }
        }elseif(isset($rdvs['date'])){
            if($rdvs['date']>$currDate){
                $html = 
                    "<div class='rdvAVenir'>
                        date: ".$rdvs['date']." ".$rdvs['miJournee']."
                        <br>
                        mail Coach: ".$rdvs['coachMail']."
                        <br>
                        Pour:".$rdvs['intitule']."
                        <br>
                        <a style='text-decoration:none' href='index.php?action=annulerRdv&rdvId=".$rdvs['id']."'>Annuler le rendez-vous</a>  
                    </div>";
                    echo($html);
            }
        }else{
            $html = 
                    "<div class='rdvAVenir'>
                    Vous n'avez pas de rdv à venir
                    </div>";
                    echo($html);
        }
    }else{
        $html = 
                    "<div class='rdvAVenir'>
                      Veuillez vous connecter pour acceder à vos rdv
                    </div>";
                    echo($html);
    }
    ?>
</div>
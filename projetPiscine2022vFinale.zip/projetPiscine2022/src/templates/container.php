<div class="containerBlank">
    <div class="containerText">
        Veuillez choisir un menu
    </div>
   
</div>
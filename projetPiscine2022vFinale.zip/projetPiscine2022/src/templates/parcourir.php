  
    <div class="navParcourir">
        <ul class="centerMenu">
            <div class="parcourirMenuButton"><a href="index.php?action=activite" class="navButton"><li><button class="btn">Activités</button></li></a></div>
            <div class="parcourirMenuButton"><a href="index.php?action=sport" class="navButton"><li><button class="btn">Sports de compétition</button></li></a></div>
            <div class="parcourirMenuButton"><a href="index.php?action=salle" class="navButton"><li><button class="btn">Salle de sport Omnes</button></li></a></div>
        </ul>
    </div>


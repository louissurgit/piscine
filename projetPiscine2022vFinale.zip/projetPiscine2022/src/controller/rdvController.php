<?php

require('src/repository/repository.php');


class RdvController{

    public function createRdv(){
        
        if(isset($_SESSION['currentUser'])){
            
            if(!empty($_SESSION['currentUser']['skype'])||$_SESSION['currentUser']['role']=='admin'){
                echo("<script> alert('Veuillez vous connecter avec un compte user pour prendre un RDV')</script>");
                return;
            }
        
            if(isset($_POST['miJournee'])){
                $userMail=$_SESSION['currentUser']['mail'];
                $coachMail=$_GET['coachMail'];
                $intitule=$_POST['intitule'];
                $miJournee=$_POST['miJournee'];
                $date=$_POST['date'];
            
                $repo = new RdvRepository();
                $result=$repo->createRdv($userMail,$coachMail,$intitule,$miJournee,$date);
                if($result){
                    echo("<script> alert('Le RDV a été enregistré, vous pouvez le voir dans votre espace RDV')</script>");
                    require('src/templates/home.php');
                }else{
                        echo("<script> alert('Il y a eu un probleme lors de la création du rdv')</script>");
                        require('src/templates/home.php');
                    }
            }
        }else{
            echo("<script> alert('Veuillez vous connecter pour prendre un RDV')</script>");
            return;
        }
    }

    public function annulerRdv($id){
        $repo = new RdvRepository();
        $result=$repo->annulerRdv($id);
        if($result){
            echo("<script> alert('Le RDV a été annulé')</script>");
            require('src/templates/home.php');
        }else{
            echo("<script> alert('Il y a eu un probleme lors de l'annulation du rdv')</script>");
            require('src/templates/home.php');
        }
    }
    



    public function getRdvsByMail($mail){
        $repo = new RdvRepository();
        $result=$repo->getRdvsByMail($mail);
        return $result;
    }

   

}
?>
<?php
class ConnexionController{

    public function getConnection(){
        if(isset($_SESSION['connected'])&&$_SESSION['connected']){
            if($_SESSION['currentUser']['role']=="user"){
                require("src/controller/rdvController.php");
                $rdvController = new RdvController();
                $currDate=date('Y-m-d');
                $rdvs=$rdvController->getRdvsByMail($_SESSION['currentUser']['mail']);
                $anciensRdv=null;
                foreach($rdvs as $rdv){
                    if($rdv['date']<$currDate){
                        $anciensRdv[]=$rdv;
                    }
                }

                require('src/templates/compte.php');
            }elseif($_SESSION['currentUser']['role']=="admin"){
                require('src/templates/admin.php');
            }else{
                require('src/templates/coach.php');
            }
        }elseif(isset($_SESSION['connected'])&&!($_SESSION['connected'])){
            session_unset();
            require('src/templates/home.php');
        }else{
            if(isset($_POST['mail'])&&isset($_POST['password'])){
                $mail=$_POST['mail'];
                $password=$_POST['password'];
                require('src/repository/repository.php');
                $repo = new UserRepository();
                $result=$repo->getUserByMail($mail,$password);
                if($result!=null){
                    $_SESSION['connected']=true;
                    $_SESSION['currentUser']=$result;
                    if($result['role']=='user'){
                        require('src/templates/compte.php');
                    }else{
                        require('src/templates/admin.php');
                    }
                }else{
                    $repo=new CoachRepository();
                    $resultCoach=$repo->getCoachByMail($mail,$password);
                    if($resultCoach!=null){
                        $_SESSION['connected']=true;
                        $_SESSION['currentUser']=$resultCoach;
                        require('src/templates/coach.php');
                    }else{
                        echo("<script> alert('Combinaison e-mail mot de passe inexistante')</script>");
                        require('src/templates/home.php');
                    }
                
                }
            }else{
                require('src/templates/login.php');
    
            }
        }
    }
    
    
}
?>
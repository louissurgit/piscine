<?php

require('src/repository/repository.php');


class FindController{

    public function find($search){
        $coachRepo = new CoachRepository();
        $resultSpecialite = $coachRepo->getOneCoachBySpecialite($search);
        $resultPrenom = $coachRepo->getCoachByPrenom($search);
        $resultNom = $coachRepo->getCoachByNom($search);
        
        require('src/templates/found.php');
        
    }

}
?>